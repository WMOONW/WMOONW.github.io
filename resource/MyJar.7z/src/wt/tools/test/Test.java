package wt.tools.test;

import wt.tools.sort.arrSort;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//1,2,3,3,5,6,88,
		//1,3,3,5,5,5,6,6,8,34,56,77,90,98,
		String[] a= {"1","3","6","5","3","88","2"};
		Integer[] b= {1,3,6,5,90,56,100,329,34,98,6,5,3,5,77,8};
		//插入
//		arrSort.insertSort(a);
//		arrSort.insertSort(b);
//		for(String t:a) {
//			System.out.println(t);
//		}
//		for(int t:b) {
//			System.out.println(t);
//		}
		//希尔
//		arrSort.shellSort(a);
//		arrSort.shellSort(b);
//		print(a);
//		print(b);
		//冒泡
//		arrSort.BubbleSort(a);
//		arrSort.BubbleSort(b);
//		print(a);
//		print(b);
		//速排
//		arrSort.quickSort(a);
//		arrSort.quickSort(b);
		//选择
//		arrSort.selectSort(a);
//		arrSort.selectSort(b);
		//堆
//		arrSort.heapSort(a);
//		arrSort.heapSort(b);
		//二路归并
		arrSort.mergeSort(a);
		arrSort.mergeSort(b);
		
		print(a);
		print(b);
	}
	public static <T extends Comparable<T>> void print(T[] t) {
		for(T temp:t) {
			System.out.print(temp+",");
		}
		System.out.println();
	}
}
