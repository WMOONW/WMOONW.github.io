package wt.tools.sort;

/*
 * 排序算法
 */
public interface arrSorter {
	public static <T extends Comparable<T>> void insertSort(T[] t) {}
	public static <T extends Comparable<T>> void shellSort(T[] t) {}
	public static <T extends Comparable<T>> void BubbleSort(T[] t) {}
	public static <T extends Comparable<T>> void quickSort(T[] t) {}
	public static <T extends Comparable<T>> void selectSort(T[] t) {}
	public static <T extends Comparable<T>> void heapSort(T[] t) {}
	public static <T extends Comparable<T>> void mergeSort(T[] t) {}
}
